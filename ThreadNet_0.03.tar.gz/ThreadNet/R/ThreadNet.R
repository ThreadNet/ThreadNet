#' @family ThreadNet_Core
#'
#' @export ThreadNet
 ThreadNet <- function() { shiny::runApp(system.file('ThreadNet', package='ThreadNet')) }
