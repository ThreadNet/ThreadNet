tabPanel(value = "parameterSettings",
    "Parameter Settings",
    tableOutput("currentParameterSettings")
)
